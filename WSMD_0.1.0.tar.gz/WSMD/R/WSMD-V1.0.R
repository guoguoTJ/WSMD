# Sys.setenv("PKG_CXXFLAGS"="-std=c++11")
motif_MIA.env <- new.env();
library("Matrix")
library("Rcpp")
library("Rmosek")
#Rcpp::sourceCpp("/media/sc2/BED0CCE0D0CCA04F/dabo/pro3/src/WSL-DMD/calculate_score_simple.cpp")
#Rcpp::sourceCpp("/media/sc2/BED0CCE0D0CCA04F/dabo/pro3/src/WSL-DMD/calculate_score_pfm.cpp")
#Rcpp::sourceCpp("/media/sc2/BED0CCE0D0CCA04F/dabo/pro3/src/WSL-DMD/mask_sequences_with_pfm.cpp")
#Rcpp::sourceCpp('/media/sc2/BED0CCE0D0CCA04F/dabo/pro3/src/WSL-DMD/seqs2sparseMatrixIndex_V1.1.cpp')
#########Must setting with "Sys.setenv("PKG_CXXFLAGS"="-std=c++11")" before compiling it#########
#Rcpp::sourceCpp('/media/sc2/BED0CCE0D0CCA04F/dabo/pro3/src/WSL-DMD/batching_fisher_exact_test.cpp')
###############################################################################################

readFasta <- function (file) {
  # read file and tell if file doesnot exist
  if (is.character(file)) {
    file <- file(file, "r")
    on.exit(close(file))
  }

  else {
    if (!inherits(file, "connection"))
      stop("'file' must be a character string or connection")
    if (!isOpen(file)) {
      open(file, "r")
      on.exit(close(file))
    }
  }

  s1 <- scan(file = file, what = "", sep = "\n", quote = "",allowEscapes = FALSE, quiet = TRUE,blank.lines.skip = T)
  return(s1[-(grep(pattern = ">",x = s1))])
}

checkSanity <- function(in.seq){
  for(i in 1:length(in.seq)){
    if(nchar(paste(sub("[ACGT]","",names(table(strsplit(in.seq[i],"")))),collapse="")) != 0)
    {
      stop(paste("",
                 "Illegal characters found in input sequences",
                 "Only permitted are A,C,G,T",
                 "Even X or small letters are not permitted",sep="\n"))
    }
  }
}

readPFM <- function(pfm.file){
  # first read all lines and make sure there are 5 lines else bomb
  all.data <- scan(pfm.file,what="characters",sep="\n",quiet=TRUE)

  if(length(all.data) != 5){
    stop("Error: illegal row number in pfm file!")
  }

  # step 2
  # read the first name line
  header <- read.table(pfm.file,nrows=1)

  # read next four lines
  pfm <- read.table(pfm.file,skip=1,nrows=4)

  # put the nucleotides as title
  row.names(pfm) <- pfm$V1

  # order the table according to nucleotides
  pfm <- pfm[order(row.names(pfm)),]

  # If order is correct and alphabets are ACGT
  if(paste(row.names(pfm),collapse="") != "ACGT"){
    stop("Error: illegal character in the column 1 of pfm file!\n")
  }
  # check if only one separator is used
  if(length(unique(pfm$V2)) != 1) {
    stop("Error: illegal character in the column 2 of pfm file!\n")
  }
  # check if that separator is pipe |
  if(unique(pfm$V2) != "|"){
    stop("Error: illegal character in the column 2 of pfm file!\n")
  }

  # remove the alphabet and separator
  pfm <- pfm[,-c(1,2)]
  # re-assign column names
  colnames(pfm) <- c(1:dim(pfm)[2])

  # return the checked PFM
  pfm
}

adjustPFM <- function(pfm.in,seq.pos.num){

  tempFun <- function(array.in,value){
    array.in[which(array.in == 0)]  <- 0.00001
    return(array.in)
  }

  # zero correction
  pfm <- apply(pfm.in,2,tempFun)

  # adjust by sum
  pfm <- t(t(pfm)/colSums(pfm))

  # assign to orig.pfm in mopEnv

  pfm

}

#generate matrix whose row vector contain all the seed ids
#which has hamming distance of 1 to the seed with row number as its id
generate.seed_hamming_matrix <- function(){
  width <- get("seed.width",envir=motif_MIA.env)
  seed.num <- 4^width
  hamming.num <- 3*width

  hamming_matrix <- matrix(0,seed.num,hamming.num)

  seed.id <- c(0:(seed.num-1))
  for(i in 1:width){
    t <- seed.id %% (4^i) %/% (4^(i-1))
    c.h <- seed.id %/% (4^i) * (4^i)
    c.d <- seed.id %% (4^(i-1))
    for(m in 1:3){
      t.temp <- (t + m) %% 4
      t.temp <- t.temp * (4^(i-1))
      hamming_matrix[,3*(i-1)+m] <- c.h + t.temp + c.d
    }
  }
  assign("hamming.matrix",hamming_matrix,envir = motif_MIA.env)
}

init.mask <- function(sequences.length){
  return(sapply(lapply(sequences.length,rep.int,x = 0),paste,collapse = ""))
}

#calculate the approximate score for seeds
select_seeds_with_sequences <- function(seed_num){
  seq.pos <- get("pos.sequences",envir=motif_MIA.env)
  seq.neg <- get("neg.sequences",envir=motif_MIA.env)
  seed.width <- get("seed.width",envir=motif_MIA.env)
  hamming.matrix <- get("hamming.matrix",envir=motif_MIA.env)
  pos.mask.up <- get("pos.mask.up",envir = motif_MIA.env)
  pos.mask.down <- get("pos.mask.down",envir = motif_MIA.env)
  neg.mask.up <- get("neg.mask.up",envir = motif_MIA.env)
  neg.mask.down <- get("neg.mask.down",envir = motif_MIA.env)

  seed.num <- 4 ^ seed.width
  seq.pos.seed_frequency <- calculate_score_simple(sequences = seq.pos,
                                                   sequences_mask_up = pos.mask.up,
                                                   sequences_mask_down = pos.mask.down,
                                                   seed_hamming = hamming.matrix,
                                                   seed_width = seed.width)

  seq.neg.seed_frequency <- calculate_score_simple(sequences = seq.neg,
                                                   sequences_mask_up = neg.mask.up,
                                                   sequences_mask_down = neg.mask.down,
                                                   seed_hamming = hamming.matrix,
                                                   seed_width = seed.width)
  dim(seq.pos.seed_frequency) <- c(seed.num,length(seq.pos.seed_frequency)/seed.num)
  dim(seq.neg.seed_frequency) <- c(seed.num,length(seq.neg.seed_frequency)/seed.num)

  preprocessing <- function(in.vector){
    #1
    num <- length(in.vector)
    #2
    num.2 <- length(which(in.vector == 2))
    #3
    num.1 <- length(which(in.vector == 1))
    #4
    num.0 <- num - num.2 - num.1
    return(c(num,num.2,num.1,num.0))
  }

  num.p <- apply(seq.pos.seed_frequency,1,preprocessing)
  num.n <- apply(seq.neg.seed_frequency,1,preprocessing)

  seed.scores <- (num.p[2,]*(num.n[4,]+num.n[3,]+num.n[1,]) +
                    num.p[3,]*(num.n[4,]+num.n[4,]+num.n[3,]) +
                    num.p[4,]*num.n[4,]) / (2*num.p[1,]*num.n[1,])

  id2pattern <- function(id,width) {
    id <- id - 1
    pattern <- NULL
    for (i in c(width:1)) {
      pattern <- c(pattern,switch(
        as.character(id %/% (4 ^ (i - 1))),
        "0" = "A",
        "1" = "C",
        "2" = "G",
        "3" = "T"
      ))
      id <- id %% (4 ^ (i - 1))
    }
    return(pattern)
  }

  pattern2pwm <- function(pattern) {
    pwm <- sapply(
      pattern, switch,
      "A" = c(1,0,0,0),
      "C" = c(0,1,0,0),
      "G" = c(0,0,1,0),
      "T" = c(0,0,0,1)
    )
    return(pwm)
  }

  pattern2id <- function(pattern) {
    temp <- cbind(pattern,c((length(pattern) - 1):0))
    id <- sum(apply(temp, 1,
                    function(x) {
                      m <- switch(
                        x[1],
                        "A" = 0,
                        "C" = 1,
                        "G" = 2,
                        "T" = 3
                      )
                      return(m * 4 ^ as.integer(x[2]))
                    })) + 1
    return(id)
  }


  seed.pwms <- list()
  names(seed.scores) <- c(1:length(seed.scores))
  delete.index <- which.min(seed.scores)
  for (i in c(1:seed_num)) {
    seed.id <- as.integer(names(which.max(seed.scores[-delete.index])))
    seed.pattern <- id2pattern(seed.id,seed.width)
    seed.pwm <- pattern2pwm(seed.pattern)
    seed.pwms[[i]] <- seed.pwm
    seed.pattern.rev <- chartr("ACGT","TGCA",rev(seed.pattern))
    seed.id.rev <- pattern2id(seed.pattern.rev)
    delete.index <- c(delete.index,seed.id,seed.id.rev)
  }
  assign("seed.pwms",seed.pwms,envir = motif_MIA.env)
}


homer2_out2standard <- function(motifs.file, motif.width, standerd_motifs.file){
  temp <- scan(motifs.file,sep = "\n",comment.char = "#",what="characters",quiet=TRUE,blank.lines.skip = T)
  is_special_line <- grep(pattern = ">",x = temp)
  pwm.n <- length(is_special_line)
  start <- is_special_line + 1
  end <- c(is_special_line[-1] - 1,length(temp))

  pwms <- NULL
  n <- 1
  # up_n <- min(pwm.n,top_n)
  while (n <= pwm.n) {
    temp_pwm <- temp[(start[n]):(end[n])]
    if((end[n])-(start[n])+1 < motif.width){
      temp_pwm <- c(temp_pwm,rep(" 0.250000  0.250000  0.250000  0.250000",motif.width- (end[n])+(start[n]) - 1))
    }
    pwms <- c(pwms,temp_pwm)
    n <- n + 1
  }
  write(x = pwms,file = standerd_motifs.file)
}

read_standerd_motifs <- function(motifs.file, motif.width){
  pwms_m <- read.table(file = motifs.file,header = F)
  motif.num <- (dim(pwms_m)[1])/motif.width
  pwms_l <- list()
  for(i in c(1:motif.num)){
    if(is.nan(pwms_m[((i-1)*motif.width+1):(i*motif.width),1])){
      pwms_l[[i]] <- matrix(data = rep(0.25,4*motif.width),nrow = 4)
    }else{
      pwms_l[[i]] <- t(pwms_m[((i-1)*motif.width+1):(i*motif.width),])
    }
  }
  return(pwms_l)
}

read_motifs_homer2_style <- function(motifs.file, motif.width){
  homer2_out2standard(motifs.file, motif.width,"temp")
  r <- read_standerd_motifs("temp",motif.width)
  return(r)
}

calculate_AUC <- function (seq.pos, seq.neg, pfm){
  checkSanity(seq.pos)
  checkSanity(seq.neg)

  seq.pos.num <- length(seq.pos)
  seq.neg.num <- length(seq.neg)

  pfm <- adjustPFM(pfm,seq.pos.num)

  temp.mask <- init.mask(sapply(seq.pos,nchar))
  names(temp.mask) <- NULL
  score <- calculate_score_pfm(sequences = seq.pos,
                               sequences_mask_up = temp.mask,
                               sequences_mask_down = temp.mask,
                               pfm = log(pfm))
  temp.mask <- init.mask(sapply(seq.neg,nchar))
  names(temp.mask) <- NULL
  score <- c(score,calculate_score_pfm(sequences = seq.neg,
                                       sequences_mask_up = temp.mask,
                                       sequences_mask_down = temp.mask,
                                       pfm = log(pfm)))

  flag <- c(rep("P",seq.pos.num),rep("N",seq.neg.num))
  flag <- flag[sort(score,index.return = T)$ix]
  auc1 <- sum(as.numeric(cumsum(flag == "N")[which(flag == "P")])) / seq.pos.num / seq.neg.num

  flag <- c(rep("N",seq.neg.num),rep("P",seq.pos.num))
  flag <- flag[sort(score[(seq.pos.num + seq.neg.num):1],index.return = T)$ix]
  auc2 <- sum(as.numeric(cumsum(flag == "N")[which(flag == "P")])) / seq.pos.num / seq.neg.num

  return((auc1+auc2)/2)
}

evaluate_PWM_AUC <- function(positive_file,
                             negative_file,
                             motif.file,motif.width){
  tr.pos_seqs <- readFasta(positive_file)
  tr.neg_seqs <- readFasta(negative_file)
  checkSanity(tr.pos_seqs)
  checkSanity(tr.neg_seqs)
  motifs <- read_motifs_homer2_style(motif.file,motif.width)
  motif.names <- names(motifs)

  motif.n <- length(motifs)
  aucs <- NULL
  for(i in c(1:motif.n)){
    print(m)
    aucs <- rbind(aucs,
                  calculate_AUC(tr.pos_seqs,
                                tr.neg_seqs,
                                motifs[[i]]))
  }
  return(aucs)
}

get_pwm_scores <- function(pos_seqs.matrix,neg_seqs.matrix,pwm){
  pwm <- Matrix(data = as.vector(pwm),nrow = 1,sparse = T)
  scores <- sapply(X = neg_seqs.matrix,FUN = function(x){return(as.vector(pwm %*% x))})
  scores <- do.call("c",scores)
  temp <- sapply(X = pos_seqs.matrix,FUN = function(x){return(as.vector(pwm %*% x))})
  scores <- c(do.call("c",temp),scores)
  return(unique(scores))
}

calculate_MHG_score <- function(pos_seqs.matrix,neg_seqs.matrix,pwm){
  scores <- get_pwm_scores(pos_seqs.matrix,neg_seqs.matrix,pwm)
  pwm <- Matrix(data = as.vector(pwm),nrow = 1,sparse = T)
  pos.scores <- sapply(X = pos_seqs.matrix,FUN = function(x){return(max(as.vector(pwm %*% x)))})
  neg.scores <- sapply(X = neg_seqs.matrix,FUN = function(x){return(max(as.vector(pwm %*% x)))})

  count_occurense_table <- function(x){
    M <- length(pos.scores)
    m <- length(which(pos.scores >= x))
    M0 <- length(neg.scores)
    m0 <- length(which(neg.scores >= x))
    #extreme cases, no need to calculate exactly
    if((M0-m0) < 10){
      return(c(1,1,1,1))
    }
    else{
      return(c(m,M,m0,M0))
    }
  }

  occurense_table <- t(sapply(scores, count_occurense_table))
  p_values <- batching_fisher_exact_test(occurense_table)
  return(min(p_values)/log(10))
}

evaluate_PWM_MHG_P_value <- function(pos_seqs.file,neg_seqs.file,
                                     motifs.file,motif.width){
  pos_seqs <- readFasta(pos_seqs.file)
  neg_seqs <- readFasta(neg_seqs.file)
  checkSanity(pos_seqs)
  checkSanity(neg_seqs)
  pos_seqs.matrix <- preprocess_seq(pos_seqs,motif.width)
  neg_seqs.matrix <- preprocess_seq(neg_seqs,motif.width)
  motifs <- read_motifs_homer2_style(motifs.file,motif.width)
  motifs_n <- length(motifs)
  fisher_exact_test_scores <- NULL
  for(m in c(1:motifs_n)){
    print(m)
    pwm <- log(adjustPFM(motifs[[m]]))
    fisher_exact_test_scores <- c(fisher_exact_test_scores,
                                  calculate_MHG_score(pos_seqs.matrix,
                                                      neg_seqs.matrix,
                                                      pwm))
  }
  return(fisher_exact_test_scores)
}

get_pwm_score_threshold <- function(neg_seqs.matrix,pwm,threshold_percent){
  pwm <- Matrix(data = as.vector(pwm),nrow = 1,sparse = T)
  scores <- lapply(X = neg_seqs.matrix,FUN = function(x){return(as.vector(pwm %*% x))})
  scores <- sort(x = do.call("c",scores),decreasing = T)
  return(scores[length(scores)*threshold_percent])
}

calculate_fisher_exact_test_score <- function(pos_seqs.matrix,neg_seqs.matrix,pwm,pwm_score_threshold){
  pwm <- Matrix(data = as.vector(pwm),nrow = 1,sparse = T)
  pos.scores <- sapply(X = pos_seqs.matrix,FUN = function(x){return(max(as.vector(pwm %*% x)))})
  neg.scores <- sapply(X = neg_seqs.matrix,FUN = function(x){return(max(as.vector(pwm %*% x)))})

  M <- length(pos.scores)
  m <- length(which(pos.scores >= pwm_score_threshold))
  M0 <- length(neg.scores)
  m0 <- length(which(neg.scores >= pwm_score_threshold))

  temp <- matrix(data = c(m,m0,(M-m),(M0-m0)),nrow = 2)
  # print(temp)
  fisher_exact_test_score <- fisher.test(x = temp)$p.value
  # print(log(fisher_exact_test_score))
  return(fisher_exact_test_score)
}

evaluate_PWM_fishers_exact_test_P_value <- function(pos_seqs.file,neg_seqs.file,
                                                    motifs.file,motif.width,
                                                    threshold_percent){
  pos_seqs <- readFasta(pos_seqs.file)
  neg_seqs <- readFasta(neg_seqs.file)
  checkSanity(pos_seqs)
  checkSanity(neg_seqs)
  pos_seqs.matrix <- preprocess_seq(pos_seqs,motif.width)
  neg_seqs.matrix <- preprocess_seq(neg_seqs,motif.width)
  motifs <- read_motifs_homer2_style(motifs.file,motif.width)

  motifs_n <- length(motifs)
  fisher_exact_test_scores <- NULL
  for(m in c(1:motifs_n)){
    print(m)
    pwm <- log(adjustPFM(motifs[[m]]))
    pwm_score_threshold <- get_pwm_score_threshold(neg_seqs.matrix,
                                                   pwm,
                                                   threshold_percent)
    fisher_exact_test_scores <- c(fisher_exact_test_scores,
                                  calculate_fisher_exact_test_score(pos_seqs.matrix,
                                                                    neg_seqs.matrix,
                                                                    pwm,
                                                                    pwm_score_threshold))
  }
  return(fisher_exact_test_scores)
}

preprocess_seq <- function(sequenes,width){
  sparseMatrixIndex <- seqs2sparseMatrixIndex(seq = sequenes,width = width)
  sub_sequenes_matrix <- lapply(X = sparseMatrixIndex,
                                FUN =  function(x){
                                  n_sub <- length(x)/width
                                  return(sparseMatrix(i = x,
                                                      j = rep(c(1:n_sub),rep(width,n_sub)),
                                                      x = 1,
                                                      dims = c(width*4,n_sub)))
                                })
}

init.parameters <- function(C = 1, neg_cache.size = 5, change_objvalue_threshold){
  pos.num <- get("pos.num",envir = motif_MIA.env)
  neg.num <- get("neg.num",envir = motif_MIA.env)
  pfm <- get("pfm",envir = motif_MIA.env)
  parameters <- list(s = rep(1,pos.num),
                     s.neg = list(size = 0,max.size = neg.num*neg_cache.size,index = as.list(x = c(1:neg.num))),
                     w = log(as.vector(as.matrix(pfm))),
                     b = 0,
                     C = C,
                     ee = rep(0,pos.num+neg.num));
  assign("parameters",parameters,envir = motif_MIA.env);
  assign("old.objvalue",change_objvalue_threshold,envir = motif_MIA.env);
  assign("new.objvalue",0,envir = motif_MIA.env);
  assign("change_objvalue_threshold",change_objvalue_threshold,envir = motif_MIA.env);
  update_s();
}

#flag = 0: seed refinement
#flag = 1: seed extension
QP_solution <- function(flag){
  pos.subsequences <- get("pos.subsequences",envir = motif_MIA.env);
  neg.subsequences <- get("neg.subsequences",envir = motif_MIA.env);
  parameters <- get("parameters",envir = motif_MIA.env);

  pos.num <- length(pos.subsequences);
  neg.num <- length(neg.subsequences);

  C <- parameters$C;
  b <- parameters$b;
  s <- parameters$s;
  s.neg <- parameters$s.neg;
  width <- get("seed.width",envir = motif_MIA.env)
  m.width <- get("motif.width",envir = motif_MIA.env)
  if(flag == 1){
    width <- get("motif.width",envir = motif_MIA.env)
  }
  length_w <- width*4

  lo1 <- list();
  lo1$sense <- "min";
  lo1$c <- c(rep(0,length_w),0,rep(C,length(parameters$ee)));
  lo1$qobj <- list(i = c(1:length_w),
                   j = c(1:length_w),
                   v = rep(1,length_w));

  constraint_pos <- sparseMatrix(i = c(1:pos.num),j = c(1:pos.num),x = 1)

  st <- (s-1)*m.width+1
  en <- st-1+width
  pos_w_sparseMatrix_index <- apply(X = cbind(c(1:pos.num),st,en),
                                    MARGIN = 1,
                                    FUN = function(x){
                                      return(pos.subsequences[[x[1]]]@i[x[2]:x[3]]+1)
                                    })
  temp <- sparseMatrix(i = rep(c(1:pos.num),rep(width,pos.num)),
                       j = as.vector(pos_w_sparseMatrix_index),
                       x = 1,
                       dims = c(pos.num,4*width))
  temp <- cbind2(temp,rep(1,pos.num))

  constraint_pos <- cbind2(temp,constraint_pos)
  constraint_pos <- cbind2(constraint_pos, Matrix(data = 0,nrow = pos.num,ncol = neg.num,sparse = T))


  neg_sub_nums <- lengths(s.neg$index) - 1
  num.all_neg <- sum(neg_sub_nums)
  end <- cumsum(neg_sub_nums)
  start <- c(1, end[-neg.num]+1)


  get_neg_w_sparseMatrix_index <- function(x){
    l <- length(x)
    if(l == 1){
      return(NULL)
    }
    else{
      s <- x[-1]
      index <- NULL
      for(i in c(1:length(s))){
        index <- c(index,c(((s[i]-1)*m.width+1):((s[i]-1)*m.width+width)))
      }
      return(neg.subsequences[[x[1]]]@i[index] + 1)
    }
  }

  neg_w_sparseMatrix_index <- lapply(X = s.neg$index, get_neg_w_sparseMatrix_index)
  constraint_neg <- sparseMatrix(i = rep(c(1:num.all_neg),rep(width,num.all_neg)),
                                 j = do.call("c",neg_w_sparseMatrix_index),
                                 x = 1,
                                 dims = c(num.all_neg,4*width))

  constraint_neg <- cbind2(constraint_neg,rep(1,num.all_neg))

  get_neg_constrain_sparse.matrix_index <- function(x){
    if(x[4] > 0){
      return(cbind2(rep(x[1],x[3]-x[2]+1),c(x[2]:x[3])))
    }
    else{
      return(NULL)
    }
  }

  sparseMatrix.index <- apply(cbind(c(1:neg.num),start,end,neg_sub_nums), 1, get_neg_constrain_sparse.matrix_index)
  if(is.list(sparseMatrix.index)){
    sparseMatrix.index <- do.call("rbind", sparseMatrix.index)
    constraint_neg_temp <- sparseMatrix(i = sparseMatrix.index[,2],j = sparseMatrix.index[,1],x = -1,dims = c(num.all_neg,neg.num))
  }
  else{
    constraint_neg_temp <- sparseMatrix(i = sparseMatrix.index[2,],j = sparseMatrix.index[1,],x = -1,dims = c(num.all_neg,neg.num))
  }
  constraint_neg_temp <- cbind2(Matrix(data = 0,nrow = num.all_neg,ncol = pos.num,sparse = T),constraint_neg_temp)
  constraint_neg <- cbind2(constraint_neg,constraint_neg_temp)


  constraint <- rbind2(constraint_pos,constraint_neg);
  lc <- c(rep(1,pos.num),rep(-Inf,dim(constraint_neg)[1]));
  uc <- c(rep(Inf,pos.num),rep(-1,dim(constraint_neg)[1]));
  lo1$A <- Matrix(constraint, sparse=TRUE);
  lo1$bc <- rbind(blc = lc,buc = uc);

  lo1$bx <- rbind(blx = c(rep(-Inf,length_w+1),rep(0,length(parameters$ee))),
                  bux = c(rep(Inf,length_w),rep(Inf,1+length(parameters$ee))));
  #************************************************************
  r <- mosek(lo1, list(soldetail = 1, verbose = 0));
  # write(paste(r$sol$itr$pobjval, r$sol$itr$dobjval),file = "")
  #************************************************************
  parameters$w[1:length_w] <- r$sol$itr$xx[1:length_w]
  parameters$b <- r$sol$itr$xx[length_w+1];
  parameters$ee <- r$sol$itr$xx[(length_w+2):length(r$sol$itr$xx)];
  assign("parameters",parameters,envir = motif_MIA.env);
  assign("QP_result",r,envir = motif_MIA.env);

  assign("old.objvalue",get("new.objvalue",envir = motif_MIA.env),envir = motif_MIA.env);
  assign("new.objvalue",r$sol$itr$pobjval,envir = motif_MIA.env);
}

update_s <- function(){
  subsequences <- get("pos.subsequences",envir = motif_MIA.env);
  parameters <- get("parameters",envir = motif_MIA.env);
  w <- Matrix(data = parameters$w,nrow = 1,ncol = length(parameters$w));
  b <- parameters$b;

  get_max <- function(one_subsequences,w,b){
    return(which.max(as.vector(w %*% one_subsequences) + b));
  }

  parameters$s <- unlist(sapply(subsequences,get_max,w,b));
  old.objvalue <- get("old.objvalue",envir = motif_MIA.env);
  new.objvalue <- get("new.objvalue",envir = motif_MIA.env);
  change_objvalue_threshold <- get("change_objvalue_threshold",envir = motif_MIA.env);
  if(abs(new.objvalue - old.objvalue) < change_objvalue_threshold){
    return(TRUE)
  }else{
    subsequences <- get("neg.subsequences",envir = motif_MIA.env)
    max.index <- unlist(sapply(subsequences,get_max,w,b))
    new.index <- lapply(X = parameters$s.neg$index,
                        FUN = function(x){
                          if(length(x) > 1){
                            return(c(x[1],union(x[-1],max.index[x[1]])))
                          }
                          else{
                            return(c(x,max.index[x]))
                          }
                        })
    new.size <- sum(lengths(new.index) - 1)
    parameters$s.neg$size <- new.size

    if(new.size > parameters$s.neg$max.size){
      #shrink cache
      neg.scores <- lapply(X = new.index,
                           FUN = function(x){
                             l <- length(x)
                             temp <- subsequences[[x[1]]][,x[2:l]]
                             return(cbind(rep(x[1],l-1),x[2:l],as.vector(w %*% temp) + b))
                           })
      neg.scores <- do.call("rbind",neg.scores)

      shrink.size <- new.size - parameters$s.neg$max.size
      shrink.index <- order(neg.scores[,3])[c(1:shrink.size)]
      for(i in c(1:shrink.size)){
        temp <- new.index[[neg.scores[shrink.index[i],1]]]
        id <- temp[1]
        temp <- temp[-1]
        temp <- temp[-which(temp == neg.scores[shrink.index[i],2])]
        new.index[[neg.scores[shrink.index[i],1]]] <- c(id,temp)
      }
      parameters$s.neg$size <- parameters$s.neg$max.size
    }

    parameters$s.neg$index <- new.index
    assign("parameters",parameters,envir = motif_MIA.env)
    return(FALSE)
  }
}


getpfm <- function(w){
  pos.subsequences <- get("pos.subsequences",envir = motif_MIA.env)

  l <- dim(w)[1]*dim(w)[2]
  w <- Matrix(data = as.vector(w), nrow = 1)
  max.subseq <- function(s,w){
    return(s[,which.max(as.vector(w %*% s))])
  }
  max.subseqs <- sapply(pos.subsequences, max.subseq, w)
  pfm <- rowSums(max.subseqs)
  dim(pfm) <- c(4,l/4)
  pfm <- apply(pfm,2,function(x) {
    return(x / sum(x))
  })
  return(pfm)
}

print_optima <- function(out.directory, motif.count){
  pwm_optima.file <- paste(out.directory,"motif_",motif.count,".txt",sep = "")
  write(paste("Outputting motif ", motif.count, " to: ",pwm_optima.file,sep = ""),file = "")
  optimal_w <- get(x = "optimal_w",envir = motif_MIA.env)
  index <- order(optimal_w[,1])
  # write("#optimal_pwms file",file = pwm_optima.file)
  file.start <- TRUE
  for(i in index){
    objvalue <- optimal_w[i,1]
    w <- optimal_w[i,-1]
    width <- length(w) / 4;
    dim(w) <- c(4,width);
    w <- exp(w);
    w <- apply(w,2,function(x) {
      return(x / sum(x))
    })
    # rownames(w) <- c("A","C","G","T");
    # colnames(w) <- c(1:width);
    # write(paste("#",objvalue),file = pwm_optima.file,append = T);
    # write.table(w,file = pwm_optima.file,quote = F,row.names = T,col.names = T,append = T);

    if(file.start){
      write(x = paste(">seed_",i,
                      "\t objvalue: ",objvalue,
                      "\t ","\t ",sep = ""),
            file = pwm_optima.file,append = F)
      file.start <- FALSE
    }else{
      write(x = paste(">Seed_",i,
                      "\t objvalue: ",objvalue,
                      "\t ","\t ",sep = ""),
            file = pwm_optima.file,append = T)
    }
    write.table(x = t(w),
                file = pwm_optima.file,
                append = T,sep = "\t",
                row.names = F,col.names = F,quote = F)
  }
}

seed.refine <- function(){
  iter = 1
  while (iter <= 1000) {
    QP_solution(flag = 0)
    if(update_s()){
      break
    }
    else{
      iter = iter + 1
    }
  }
}

seed.extension <- function(out.directory,m){
  seed.width <- get("seed.width",envir = motif_MIA.env)
  motif.width <- get("motif.width",envir = motif_MIA.env)
  seed.w <- get("parameters",envir = motif_MIA.env)$w[1:(4*seed.width)]
  extension.parameters <- list()
  extension.objvalue <- NULL

  for(n in c(0:(motif.width-seed.width))){
    if(n != 0){
      parameters <- get("parameters",envir = motif_MIA.env)
      parameters$s.neg$size <- 0
      l <- length(parameters$s.neg$index)
      parameters$s.neg$index <- as.list(x = c(1:l))
      parameters$b <- 0
      parameters$w <- rep(log(0.25),4*motif.width)
      parameters$w[(4*n+1):(4*(n+seed.width))] <- seed.w
      assign("parameters",parameters,envir = motif_MIA.env)
      assign("new.objvalue",0,envir = motif_MIA.env)
      update_s()
    }
    iter = 1
    while (iter <= 1000) {
      QP_solution(flag = 1)
      if(update_s()){
        extension.objvalue <- c(extension.objvalue,get("new.objvalue",envir = motif_MIA.env))
        extension.parameters[[n+1]] <- get("parameters",envir = motif_MIA.env)
        break
      }
      else{
        iter = iter + 1
      }
    }
  }
  optimal.index <- which.min(extension.objvalue)
  assign("parameters",extension.parameters[[optimal.index]],envir = motif_MIA.env)
  optimal_w <- rbind(get(x = "optimal_w",envir = motif_MIA.env),c(min(extension.objvalue),extension.parameters[[optimal.index]]$w))
  assign("optimal_w",optimal_w,envir = motif_MIA.env);
}

masking <- function(){
  pos.subsequences <- get("pos.subsequences",envir=motif_MIA.env)
  seq.pos <- get("pos.sequences",envir=motif_MIA.env)
  pos.mask.up <- get("pos.mask.up",envir = motif_MIA.env)
  pos.mask.down <- get("pos.mask.down",envir = motif_MIA.env)
  parameters <- get("parameters",envir = motif_MIA.env)
  pos.num <- length(pos.subsequences)
  pos.s <- parameters$s
  w <- parameters$w;
  width <- length(w) / 4;
  dim(w) <- c(4,width);
  w <- exp(w);
  w <- apply(w,2,function(x) {
    return(x / sum(x))
  })
  seq.mask <- mask_sequences_with_pfm(sequences = seq.pos,
                                      sequences_mask_up = pos.mask.up,
                                      sequences_mask_down = pos.mask.down,
                                      pfm = w)
  assign("pos.mask.up",seq.mask[[1]],envir = motif_MIA.env)
  assign("pos.mask.down",seq.mask[[2]],envir = motif_MIA.env)

  st <- (pos.s-1)*width+1
  en <- st-1+width
  pos_w_sparseMatrix_index <- lapply(X = c(1:pos.num),
                                     FUN = function(x){
                                       return(pos.subsequences[[x]]@i[-c((st[x]):(en[x]))]+1)
                                     })
  sub_sequenes_matrix <- lapply(X = pos_w_sparseMatrix_index,
                                FUN =  function(x){
                                  n_sub <- length(x)/width
                                  return(sparseMatrix(i = x,
                                                      j = rep(c(1:n_sub),rep(width,n_sub)),
                                                      x = 1,
                                                      dims = c(width*4,n_sub)))
                                })
  assign("pos.subsequences",sub_sequenes_matrix,envir = motif_MIA.env)
}

#MI-SVM & hard negative
#Selecting seeds as DiscMLA
#can check the AUC of pfm
#accelerate preprocess_seq with sparseMatrix (improve almost a half)
#change the terminal condition as change(r$sol$itr$pobjval) < threshold
#calculate the aucs of PWM
#implement the core of preprocess_seq with Rcpp function seqs2sparseMatrixIndex (near-perfect)
#extend width
#allow user defined input motifs, then motif_MIA is utilized to optimize them
#calculate the approximate score for seeds with subsequences matrix
WSMD <- function(positive.file = NULL,
                    negative.file = NULL,
                    out.directory = NULL,
                    motif.file = NULL,
                    C = 10,
                    seed.num = 1,
                    seed.width = 6,
                    motif.num = 1,
                    motif.width = 8,
                    neg_cache.size = 3,
                    change_objvalue_threshold = 0.5){
  write("Read and process positive sequences...",file = "")
  pos.sequences <- readFasta(positive.file)
  pos.subsequences <- preprocess_seq(pos.sequences,motif.width)
  assign("pos.subsequences",pos.subsequences,envir = motif_MIA.env)

  write("Read and process negative sequences...",file = "")
  neg.sequences <- readFasta(negative.file)
  neg.subsequences <- preprocess_seq(neg.sequences,motif.width)
  assign("pos.sequences",pos.sequences,envir = motif_MIA.env)
  assign("neg.sequences",neg.sequences,envir = motif_MIA.env)
  assign("neg.subsequences",neg.subsequences,envir = motif_MIA.env)

  pos.num <- length(pos.subsequences)
  neg.num <- length(neg.subsequences)
  assign("pos.num",pos.num,envir = motif_MIA.env)
  assign("neg.num",neg.num,envir = motif_MIA.env)

  assign("seed.width",seed.width,envir = motif_MIA.env)
  assign("motif.width",motif.width,envir = motif_MIA.env)
  generate.seed_hamming_matrix()
  temp.mask <- init.mask(sapply(pos.sequences,nchar))
  names(temp.mask) <- NULL
  assign("pos.mask.up",temp.mask,envir = motif_MIA.env)
  assign("pos.mask.down",temp.mask,envir = motif_MIA.env)
  temp.mask <- init.mask(sapply(neg.sequences,nchar))
  names(temp.mask) <- NULL
  assign("neg.mask.up",temp.mask,envir = motif_MIA.env)
  assign("neg.mask.down",temp.mask,envir = motif_MIA.env)
  seed.pwms <- NULL
  if(is.null(motif.file)){
    write("Generating seeds for motif 1...",file = "")
    select_seeds_with_sequences(seed_num = seed.num)
    seed.pwms <- get("seed.pwms",envir = motif_MIA.env)
    write("Done!",file = "")
  }else{
    write("Reading motifs from file...",file = "")
    seed.pwms <- read_motifs_homer2_style(motif.file = motif.file,motif.width = motif.width)
    assign("seed.pwms",seed.pwms,envir = motif_MIA.env)
    seed.width <- motif.width
    assign("seed.width",seed.width,envir = motif_MIA.env)
    motif.num <- 1
    seed.num <- length(seed.pwms)
    write(paste("Read ",seed.num," motifs!",sep = ""),file = "")
  }
  dir.create(out.directory)
  for(motif.count in c(1:motif.num)){
    assign("optimal_w",NULL,envir = motif_MIA.env)
    for(m in c(1:seed.num)){
      write(paste("Refining seed ",m," for motif ",motif.count,"...",sep = ""),file = "")
      pfm <- adjustPFM(seed.pwms[[m]],length(pos.sequences))
      if(seed.width < motif.width){
        pfm <- cbind2(pfm, matrix(rep(0.25,4*(motif.width - seed.width)),nrow = 4))
      }
      assign("pfm",pfm,envir = motif_MIA.env)
      init.parameters(C, neg_cache.size = neg_cache.size, change_objvalue_threshold)
      seed.refine()
      write("Done!",file = "")
      write(paste("Extending seed ",m," for motif ",motif.count,"...",sep = ""),file = "")
      seed.extension()
      write("Done!",file = "")
    }
    print_optima(out.directory,motif.count)
    if(motif.count < motif.num){
      write(paste("Masking the occurrenses of motif ",motif.count,"...",sep = ""),file = "")
      masking()
      write("Done!",file = "")
      write(paste("Generating seeds for motif ",motif.count+1,"...",sep = ""),file = "")
      select_seeds_with_sequences(seed_num = seed.num)
      seed.pwms <- get("seed.pwms",envir = motif_MIA.env)
      write("Done!",file = "")
    }
  }
}

# a <- Sys.time()
# system.time(WSMD(positive.file = "E:/dabo/pro3/data/Synthetic_data_v2.0/test-speed/positive_sequences.fasta",
#                          negative.file = "E:/dabo/pro3/data/Synthetic_data_v2.0/test-speed/negative_sequences.fasta",
#                          out.directory = "E:/dabo/pro3/data/Synthetic_data_v2.0/test-speed/MIA6173/")
# )
# b <- Sys.time()
# print(difftime(b,a,tz = "secs"))


# auc <- evaluate_PWM_AUC(positive_file = "E:/dabo/pro3/data/Synthetic_data_v2.0/test-speed/positive_sequences.fasta",
#                         negative_file = "E:/dabo/pro3/data/Synthetic_data_v2.0/test-speed/negative_sequences.fasta",
#                         motif.file = "E:/dabo/pro3/data/Synthetic_data_v2.0/test-speed/MIA6173/motif_1.txt",
#                         motif.width = 8)

# pvalue <- evaluate_PWM_fishers_exact_test_P_value(pos_seqs.file = "/media/sc2/BED0CCE0D0CCA04F/dabo/pro3/data/134-datasets/seq/training_test_V1.0/wgEncodeHaibTfbsA549Usf1Pcr1xDex100nmPkRep1_training_1_positive.fasta",
#                                                   neg_seqs.file = "/media/sc2/BED0CCE0D0CCA04F/dabo/pro3/data/134-datasets/seq/training_test_V1.0/wgEncodeHaibTfbsA549Usf1Pcr1xDex100nmPkRep1_training_1_negative.fasta",
#                                                   motifs.file = "/media/sc2/BED0CCE0D0CCA04F/dabo/pro3/data/134-datasets/results/training_test_V1.0/homer2/wgEncodeHaibTfbsA549Usf1Pcr1xDex100nmPkRep1_training_1",
#                                                   motif.width = 8,threshold_percent = 0.001)

# pvalue <- evaluate_PWM_MHG_P_value("/media/sc2/BED0CCE0D0CCA04F/dabo/pro3/data/134-datasets/seq/training_test_V1.0/wgEncodeHaibTfbsA549Usf1Pcr1xDex100nmPkRep1_training_1_positive.fasta",
#                                    "/media/sc2/BED0CCE0D0CCA04F/dabo/pro3/data/134-datasets/seq/training_test_V1.0/wgEncodeHaibTfbsA549Usf1Pcr1xDex100nmPkRep1_training_1_negative.fasta",
#                                    "/media/sc2/BED0CCE0D0CCA04F/dabo/pro3/data/134-datasets/results/training_test_V1.0/homer2/wgEncodeHaibTfbsA549Usf1Pcr1xDex100nmPkRep1_training_1",
#                                    8)
# auc <- evaluate_PWM_AUC("/media/sc2/BED0CCE0D0CCA04F/dabo/pro3/data/134-datasets/seq/training_test_V1.0/wgEncodeHaibTfbsA549Usf1Pcr1xDex100nmPkRep1_training_2_positive.fasta",
#                  "/media/sc2/BED0CCE0D0CCA04F/dabo/pro3/data/134-datasets/seq/training_test_V1.0/wgEncodeHaibTfbsA549Usf1Pcr1xDex100nmPkRep1_training_2_negative.fasta",
#                  "/media/sc2/BED0CCE0D0CCA04F/dabo/pro3/data/134-datasets/results/training_test_V1.0/homer2/wgEncodeHaibTfbsA549Usf1Pcr1xDex100nmPkRep1_training_2",
#                  8)
