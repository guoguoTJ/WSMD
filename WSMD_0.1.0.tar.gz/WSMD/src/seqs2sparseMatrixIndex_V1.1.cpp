#include <Rcpp.h>
#include<map>
using namespace Rcpp;
// [[Rcpp::export]]
List seqs2sparseMatrixIndex(List seq,int width) {
  std::map<char,int> myMap;
  myMap['A']=1;
  myMap['C']=2;
  myMap['G']=3;
  myMap['T']=4;
  int seqNum=seq.size();
  List list(seqNum);
  for(int m=0;m<seqNum;m++){
    std::string temp_sequence = as<std::string>(seq(m));
    int seqLen=temp_sequence.length();
    int sliceLen=seqLen-width+1;
    int tempLen=sliceLen*width;
    NumericVector tempMat=NumericVector(tempLen*2);
    int n=0;
    int count=0;
    int temp;
    for(int i=0;i<sliceLen;i++){
      n=i;
      for(int j=0;j<width;j++){
        //std::cout<<"i="<<i<<" j="<<j<<" n="<<n<<" count="<<count<<std::endl;
        temp=myMap[temp_sequence[n]];
        tempMat(count)=temp+4*j;
        tempMat(2*tempLen-count-1)=5-temp+4*(width-j-1);
        count++;
        n++;
      }
    }
    
    list(m)=tempMat;
  }
  
  return list;
}
