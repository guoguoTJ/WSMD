#include <Rcpp.h>
#include<cmath>
#include<map>
#include<iostream>
using namespace Rcpp;

const double _log10 = log(10);
const double _log_zero = -1e10;
const double _log_small = -0.5e10;
const double _mm_nats = log(-_log_zero);

double my_exp(double x);
double log_sum1(double logx, double logy);
double log_sum(double logx, double logy);
double lngamm(double z);

static std::map<int, double> _lnfact_hash;
double lnfact(int n);
double lnbico(int n, int k);
double log_hyper_323(int n11, int n1_, int n_1, int n);

static int _sn11, _sn1_, _sn_1, _sn;
static double _log_sprob = 0;
double log_hyper0(int n11i, int n1_i, int n_1i, int ni);
double log_hyper(int n11);

const double _log0_9999999 = log(0.9999999);
const double _log1_0000001 = log(1.00000001);
double log_getFETprob(int a1, int a2, int b1, int b2);
double calFisherExactTest(int p, int P, int n, int N);

double my_exp(double x) {
  if(x < _log_small) return 0.0;
  else return exp(x);
}

double log_sum1(double logx, double logy) {
  if((logx - logy) > _mm_nats) return logx;
  else return logx + log(1 + my_exp(logy - logx));
}

double log_sum(double logx, double logy) {
  // Return the log(x+y) given log(x) and log(y).
  if(logx > logy) return log_sum1(logx, logy);
  else return log_sum1(logy, logx);
}

double lngamm(double z) {
  double x = 0.0;
  x = x + 0.1659470187408462e-06/(z+7.0);
  x = x + 0.9934937113930748e-05/(z+6.0);
  x = x - 0.1385710331296526    /(z+5.0);
  x = x + 12.50734324009056     /(z+4.0);
  x = x - 176.6150291498386     /(z+3.0);
  x = x + 771.3234287757674     /(z+2.0);
  x = x - 1259.139216722289     /(z+1.0);
  x = x + 676.5203681218835     /(z);
  x = x + 0.9999999999995183;
  return log(x)-5.58106146679532777-z+(z-0.5)*log(z+6.5);
}


double lnfact(int n) {
  if(n <= 1) return 0.0;
  if(_lnfact_hash.find(n) != _lnfact_hash.end()) return _lnfact_hash[n];

  double result = lngamm(n + 1.0);
  _lnfact_hash[n] = result;
  return result;
}

double lnbico(int n, int k) {
  return lnfact(n) - lnfact(k) - lnfact(n-k);
}

double log_hyper_323(int n11, int n1_, int n_1, int n) {
  return lnbico(n1_, n11) + lnbico(n-n1_, n_1-n11) - lnbico(n,n_1);
}


double log_hyper0(int n11i, int n1_i, int n_1i, int ni) {
  if(!((n1_i||n_1i||ni)!=0)) {
    if(!(n11i % 10 == 0)) {
      if(n11i == _sn11+1) {
        _log_sprob = _log_sprob + log(((_sn1_-_sn11)/float(n11i))*((_sn_1-_sn11)/float(n11i+_sn-_sn1_-_sn_1)));
        _sn11 = n11i;
        return _log_sprob;
      }
      if(n11i == _sn11-1) {
        _log_sprob = _log_sprob + log(((_sn11)/float(_sn1_-n11i))*((_sn11+_sn-_sn1_-_sn_1)/float(_sn_1-n11i)));
        _sn11 = n11i;
        return _log_sprob;
      }
    }
    _sn11 = n11i;
  }else {
    _sn11 = n11i;
    _sn1_ = n1_i;
    _sn_1 = n_1i;
    _sn = ni;
  }
  _log_sprob = log_hyper_323(_sn11, _sn1_, _sn_1, _sn);
  return _log_sprob;
}

double log_hyper(int n11) {
  return log_hyper0(n11, 0, 0, 0);
}



double log_getFETprob(int a1, int a2, int b1, int b2) {
  /* Computes Fisher's exact test based on a
  null-hypothesis distribution specified by the totals, and
  an observed distribution specified by b1 and b2, i.e.
  determines the probability of b's outcomes 1 and 2.

  Returns an immutable list consisting of the exact
  probability, and assorted p-values (sless, sright, sleft,
                                      slarg) based on the density. */

  double log_sless = _log_zero, log_sright = _log_zero, log_sleft = _log_zero, log_slarge = _log_zero;
  int n = a1 + a2 + b1 + b2;
  int row1 = a1 + a2; // the row containing the null hypothesis
  int col1 = a1 + b1; // the column containing samples for outcome 1
  int max = row1;
  if(col1 < max) max = col1;
  int min = row1 + col1 - n;
  if(min < 0) min = 0;
  if(min == max) {
    double log_prob = 0;
    log_sless = log_sright = log_sleft = log_slarge = 0;
    return log_slarge;
  }

  double log_prob = log_hyper0(a1, row1, col1, n);
  log_sleft = _log_zero;
  double log_p = log_hyper(min);

  int i = min + 1;
  while(log_p < (_log0_9999999 + log_prob)) {
    log_sleft = log_sum(log_sleft, log_p);
    log_p = log_hyper(i);
    i++;
  }

  i = i - 1;
  if(log_p < (_log1_0000001 + log_prob)) log_sleft = log_sum(log_sleft, log_p);
  else i = i - 1;

  log_sright = _log_zero;
  log_p = log_hyper(max);

  int j = max - 1;
  while(log_p < (_log0_9999999 + log_prob)) {
    log_sright = log_sum(log_sright, log_p);
    log_p = log_hyper(j);
    j = j - 1;
  }

  j = j + 1;
  if(log_p < (_log1_0000001 + log_prob)) log_sright = log_sum(log_sright, log_p);
  else j = j + 1;

  if(std::abs(i-a1) < std::abs(j-a1)) {
    log_sless = log_sleft;
    //log_slarge = (log_slarge, log_prob);
    log_slarge = log(1.0 - exp(log_sleft));
    log_slarge = log_sum(log_slarge, log_prob);
  }else {
    //log_sless = log_sum(1.0, -log_sright);
    log_sless = log(1.0 - exp(log_sright));
    //log_sless = (log_sless, log_prob);
    log_sless = log_sum(log_sless, log_prob);
    log_slarge = log_sright;
  }
  return log_slarge;
}

double calFisherExactTest(int p, int P, int n, int N)
{
  /*Return log of hypergeometric pvalue of #pos >= p
   p = positive successes
   P = positives
   n = negative successes
   N = negatives
   */
  //check that p-value is less than 0.5
  //if p/float(P) > n/float(N):
  //if (p * N > n * P)
  //apply Fisher's Exact test (hypergeometric p-value)
  return log_getFETprob(N-n, n, P-p, p);
  //else return 0;
}

// [[Rcpp::export]]
NumericVector batching_fisher_exact_test(NumericMatrix x) {
  int x_nrow = x.nrow();
  NumericVector p_values(x_nrow);
  for(int m=0;m<x_nrow;m++){
    p_values[m] = calFisherExactTest(x(m,0),x(m,1),x(m,2),x(m,3));
  }
  return p_values;
}


