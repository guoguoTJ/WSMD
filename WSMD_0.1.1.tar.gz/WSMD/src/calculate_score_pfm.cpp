#include <Rcpp.h>
using namespace Rcpp;

//根据pfm计算序列得分
// [[Rcpp::export]]
NumericVector calculate_score_pfm(CharacterVector sequences,CharacterVector sequences_mask_up,CharacterVector sequences_mask_down,NumericMatrix pfm){
  int up[20] = {0, -1, 1, -1, -1, -1, 2, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 3};
  int down[20] = {3, -1, 2, -1, -1, -1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0};
  int pfm_width = pfm.ncol();
  int sequence_num = sequences.size();
  NumericVector score(sequence_num);
  for(int i=0;i<sequence_num;i++){
    score[i] = -99999999.0;
  }
  for(int m=0;m<sequence_num;m++){
    std::string temp_sequence = as<std::string>(sequences(m));
    std::string temp_sequence_mask_up = as<std::string>(sequences_mask_up(m));
    std::string temp_sequence_mask_down = as<std::string>(sequences_mask_down(m));
    int seq_length = temp_sequence.length();
    for(int n=0;n<seq_length;n++){
      int end = n+pfm_width;
      if(end > seq_length){
        break;
      }
      
      bool up_is_masked = ((temp_sequence_mask_up[n] == '1') & (temp_sequence_mask_up[end-1] == '1'));
      bool down_is_masked = ((temp_sequence_mask_down[n] == '1') & (temp_sequence_mask_down[end-1] == '1'));
      
      if(up_is_masked && down_is_masked){
        //std::cout<<"up_is_masked && down_is_masked: "<<n+1<<" "<<end<<std::endl;
        continue;
      }
      else if(!up_is_masked && down_is_masked){
        //std::cout<<"!up_is_masked && down_is_masked: "<<n+1<<" "<<end<<std::endl;
        double score_up = 0.0;
        for(int p=n;p<end;p++){        
          score_up += pfm(up[temp_sequence[p] - 'A'],p-n);
        }
        if(score_up > score[m]){
          score[m] = score_up;
        }
      }
      else if(up_is_masked && !down_is_masked){
        //std::cout<<"up_is_masked && !down_is_masked: "<<n+1<<" "<<end<<std::endl;
        double score_down = 0.0;
        for(int p=n;p<end;p++){        
          score_down += pfm(down[temp_sequence[p] - 'A'],pfm_width-1-(p-n));
        }
        if(score_down > score[m]){
          score[m] = score_down;
        }
      }
      else{
        //std::cout<<"!up_is_masked && !down_is_masked: "<<n+1<<" "<<end<<std::endl;
        double score_up = 0.0;
        double score_down = 0.0;
        for(int p=n;p<end;p++){        
          int num = temp_sequence[p] - 'A';
          score_up += pfm(up[num],p-n);
          score_down += pfm(down[num],pfm_width-1-(p-n));
        }
        double temp_score = score_up;
        if(score_down > temp_score){
          temp_score = score_down;
        }
        if(temp_score > score[m]){
          score[m] = temp_score;
        }
      }      
    }
  }
  return score;
}

