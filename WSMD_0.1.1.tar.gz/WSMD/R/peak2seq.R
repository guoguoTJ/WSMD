library("ChIPpeakAnno")
library("BSgenome.Hsapiens.UCSC.hg19")

getAllPeakSequence_qiuck_FgBg <- function(peak.data, genome, useful.cols){
  myPeakList <- BED2RangedData(peak.data[useful.cols], genome,header = F)
  pos.chr <- paste("chr", space(myPeakList), sep = "")
  pos.strand <- myPeakList$strand
  pos.start <- start(myPeakList)
  pos.end <- end(myPeakList)
  pos.width <- width(myPeakList)
  pos.name <- rownames(myPeakList)
  iRange <- IRanges(start = pos.start, end = pos.end,  names = pos.name)
  fg.gRange <- GRanges(seqnames = pos.chr, ranges = iRange, strand = pos.strand, seqlengths = NULL, seqinfo = NULL)
  fg.seq <- getSeq(genome, fg.gRange, as.character = TRUE)
  names(fg.seq) <- NULL

  pos.num <- length(fg.seq)
  neg.flag <- sample(c(T,F),pos.num,replace = T)
  pos.start_end <- cbind(pos.start,pos.end,pos.width,neg.flag)
  neg.start_end.function <- function(x){
    gap <- sample(c(1:100),1)
    if(x[4]){
      neg.start <- x[1] - x[3] - gap
      neg.end <- x[2] - x[3] - gap
      if(neg.start <= 0){
        warning("Out of boundary!",immediate. = T)
        neg.start <- x[1] + x[3] + gap
        neg.end <- x[2] + x[3] + gap
      }
    }else{
      neg.start <- x[1] + x[3] + gap
      neg.end <- x[2] + x[3] + gap
    }
    return(c(neg.start,neg.end))
  }
  neg.start_end <- apply(pos.start_end,1,neg.start_end.function)
  iRange <- IRanges(start = neg.start_end[1,], end = neg.start_end[2,], names = pos.name)
  bg.gRange <- GRanges(seqnames = pos.chr, ranges = iRange, strand = pos.strand, seqlengths = NULL, seqinfo = NULL)
  bg.seq <- getSeq(genome, bg.gRange, as.character = TRUE)
  names(bg.seq) <- NULL

  return(list(fg.seq = fg.seq,bg.seq = bg.seq))
}

peak2seq <- function(peak.file,
                     genome = BSgenome.Hsapiens.UCSC.hg19,
                     max.seq_num  = 2000,
                     min.seq_num  = 0,
                     max.base_num  = 1000,
                     min.base_num  = 100,
                     output.flag){
  peak.data <- read.table(peak.file,header = F)
  peak.data <- peak.data[,1:5]
  cat("The input file","has",dim(peak.data)[1],"peaks.","\n")
  peak.data <- peak.data[which(min.base_num <= (peak.data[,3] - peak.data[,2]) & (peak.data[,3] - peak.data[,2]) <= max.base_num),]
  cat("The input file","has",dim(peak.data)[1],"peaks which have suitable sequence length.","\n")

  seq.num <- max.seq_num
  if(min.seq_num <= (dim(peak.data)[1])){
    if((dim(peak.data)[1]) < max.seq_num){
      seq.num <- dim(peak.data)[1]
    }
    else{
      cat(paste("The number of peaks is greater than ", max.seq_num, ", so only the top scored peaks will be saved.", sep = ""), "\n");
      peak.data <- peak.data[sort(peak.data[,5],decreasing = T,index.return = T)$ix[1:max.seq_num],]
    }
    row.names(peak.data) <- NULL
    peak.ranger <- BED2RangedData(peak.data, header = F)
    seq.details <- getAllPeakSequence_qiuck_FgBg(peak.data, genome = genome, c(1:5))

    seq.num <- length(seq.details$fg.seq)
    out.file <- paste(output.flag,"_positive.txt",sep = "")
    cat("The",seq.num,"positive sequences will be writed to",out.file,"\n")
    temp <- rep("",2*seq.num)
    temp[seq(1,2*seq.num,2)] <- paste(">pos.seq",c(1:seq.num))
    temp[seq(2,2*seq.num,2)] <- seq.details$fg.seq
    write(temp,out.file)

    seq.num <- length(seq.details$bg.seq)
    out.file <- paste(output.flag,"_negative.txt",sep = "")
    cat("The",seq.num,"negative sequences will be writed to",out.file,"\n")
    temp <- rep("",2*seq.num)
    temp[seq(1,2*seq.num,2)] <- paste(">neg.seq",c(1:seq.num))
    temp[seq(2,2*seq.num,2)] <- seq.details$bg.seq
    write(temp,out.file)
  }
}
